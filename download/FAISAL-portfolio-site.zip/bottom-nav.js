/* ==========================================================================
   FAISAL — Premium Mobile Bottom Navigation (v2)
   Renders a 5-item floating glass nav bar on mobile (≤ 768px):
     Home · Portfolio · About · Blog · Contact
   All 5 main pages are now reachable on mobile — no more missing "About"!
   ========================================================================== */
(function () {
  'use strict'

  if (window.__FAISAL_BOTTOM_NAV_LOADED__) return
  window.__FAISAL_BOTTOM_NAV_LOADED__ = true

  // Premium outlined SVG icons (stroke-based, modern style)
  const ICONS = {
    home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12L12 3l9 9"/><path d="M5 10v10h4v-6h6v6h4V10"/></svg>',
    portfolio: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 5V3h8v2"/><path d="M3 10h18"/></svg>',
    about: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21v-1a8 8 0 0 1 16 0v1"/></svg>',
    blog: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5v14h16V8l-3-3z"/><path d="M8 13h8M8 17h5M8 9h4"/></svg>',
    contact: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h16v12H4z"/><path d="M4 7l8 6 8-6"/></svg>',
  }

  // Detect current page to mark the active nav item
  function getCurrentPage() {
    const path = window.location.pathname.split('/').pop() || 'index.html'
    if (path === '' || path === 'index.html') return 'home'
    if (path === 'portfolio.html') return 'portfolio'
    if (path === 'blog.html') return 'blog'
    if (path === 'contact.html') return 'contact'
    if (path === 'about.html') return 'about'
    return 'home'
  }

  function buildNav() {
    const current = getCurrentPage()

    // 5 distinct pages — all reachable on mobile
    const items = [
      { id: 'home', label: 'Home', href: '/index.html', icon: ICONS.home },
      { id: 'portfolio', label: 'Work', href: '/portfolio.html', icon: ICONS.portfolio },
      { id: 'about', label: 'About', href: '/about.html', icon: ICONS.about },
      { id: 'blog', label: 'Blog', href: '/blog.html', icon: ICONS.blog },
      { id: 'contact', label: 'Talk', href: '/contact.html', icon: ICONS.contact },
    ]

    const nav = document.createElement('nav')
    nav.className = 'fa-bottom-nav'
    nav.setAttribute('aria-label', 'Mobile bottom navigation')

    items.forEach(function (item) {
      const a = document.createElement('a')
      a.className = 'fa-bottom-nav-item' + (item.id === current ? ' is-active' : '')
      a.href = item.href
      a.setAttribute('aria-label', item.label)
      a.setAttribute('aria-current', item.id === current ? 'page' : 'false')
      a.innerHTML = item.icon + '<span>' + item.label + '</span>'
      nav.appendChild(a)
    })

    return nav
  }

  function init() {
    if (window.matchMedia('(max-width: 768px)').matches) {
      document.body.appendChild(buildNav())
    }

    let lastMobile = window.matchMedia('(max-width: 768px)').matches
    window.addEventListener('resize', function () {
      const nowMobile = window.matchMedia('(max-width: 768px)').matches
      if (nowMobile !== lastMobile) {
        lastMobile = nowMobile
        const existing = document.querySelector('.fa-bottom-nav')
        if (nowMobile && !existing) {
          document.body.appendChild(buildNav())
        } else if (!nowMobile && existing) {
          existing.remove()
        }
      }
    })
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }
})()
