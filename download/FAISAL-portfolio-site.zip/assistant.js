/* ==========================================================================
   FAISAL — AI Brand Concierge Widget (client logic)
   Self-contained: creates its own DOM, manages state, calls /api/chat.
   ========================================================================== */
(function () {
  'use strict'

  // Don't double-init if the script is loaded twice
  if (window.__FAISAL_ASSISTANT_LOADED__) return
  window.__FAISAL_ASSISTANT_LOADED__ = true

  // ----- SVG icons (inline so no extra requests) -----
  const ICONS = {
    launcher:
      '<svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12c0 1.54.36 2.99.97 4.29L1 23l6.71-1.97C9.01 21.64 10.46 22 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm-1 14.5l-4-4 1.41-1.41L11 13.67l5.59-5.59L18 9.5l-7 7z"/></svg>',
    send: '<svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>',
    close: '<svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>',
  }

  // ----- State -----
  const STORAGE_KEY = 'faisal_assistant_history_v1'
  let conversation = [] // array of {role, content}
  let isOpen = false
  let isTyping = false

  // Greeting shown on first open (shorter for faster perceived speed)
  const GREETING =
    "Hi, I'm Mehar — FAISAL's AI Concierge. Ask me about SEO, WordPress, branding, or get an instant project cost estimate."

  // Quick reply suggestions shown under the greeting
  const QUICK_REPLIES = [
    'Estimate my project cost',
    'Tell me about your SEO services',
    'How fast can you build a WordPress site?',
    'I want to hire FAISAL',
  ]

  // ----- Persistence (per-browser) -----
  function loadHistory() {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw)
        if (Array.isArray(parsed)) return parsed
      }
    } catch (_) {}
    return []
  }

  function saveHistory() {
    try {
      // Keep only last 20 messages to stay under sessionStorage limits
      const trimmed = conversation.slice(-20)
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed))
    } catch (_) {}
  }

  // ----- DOM build -----
  function buildLauncher() {
    const btn = document.createElement('button')
    btn.className = 'fa-launcher'
    btn.setAttribute('aria-label', 'Open FAISAL AI assistant')
    btn.innerHTML = ICONS.launcher
    btn.addEventListener('click', togglePanel)
    return btn
  }

  function buildPanel() {
    const panel = document.createElement('div')
    panel.className = 'fa-panel'
    panel.setAttribute('role', 'dialog')
    panel.setAttribute('aria-label', 'FAISAL AI Brand Concierge')
    panel.innerHTML = `
      <div class="fa-header">
        <div class="fa-avatar" aria-hidden="true">F</div>
        <div class="fa-header-info">
          <p class="fa-header-name">Mehar · FAISAL AI Concierge</p>
          <p class="fa-header-status">Online · replies instantly</p>
        </div>
        <button class="fa-close-btn" aria-label="Close assistant">${ICONS.close}</button>
      </div>
      <div class="fa-messages" id="fa-messages"></div>
      <div class="fa-quick-replies" id="fa-quick-replies"></div>
      <div class="fa-input-area">
        <textarea class="fa-input" id="fa-input" rows="1"
          placeholder="Ask me anything about FAISAL's services..."
          aria-label="Type your message"></textarea>
        <button class="fa-send-btn" id="fa-send" aria-label="Send message">${ICONS.send}</button>
      </div>
      <div class="fa-footer">
        Powered by <a href="contact.html">FAISAL · Digital Growth Architect</a>
      </div>
    `
    // Wire up events
    panel.querySelector('.fa-close-btn').addEventListener('click', closePanel)
    panel.querySelector('#fa-send').addEventListener('click', handleSend)
    const input = panel.querySelector('#fa-input')
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault()
        handleSend()
      }
    })
    input.addEventListener('input', autoResize)
    return panel
  }

  function autoResize() {
    const input = document.getElementById('fa-input')
    if (!input) return
    input.style.height = 'auto'
    input.style.height = Math.min(input.scrollHeight, 100) + 'px'
  }

  // ----- Render helpers -----
  function appendMessage(role, content) {
    const wrap = document.getElementById('fa-messages')
    if (!wrap) return
    const div = document.createElement('div')
    div.className = 'fa-msg ' + (role === 'user' ? 'is-user' : 'is-ai')

    if (role === 'assistant') {
      // Detect a "💡 Pro Tip:" line and split it into a styled callout.
      // We support both the emoji prefix and a plain "Pro Tip:" prefix.
      const protipMatch = content.match(/^(.*?)(\n*\s*[💡✨\*]?\s*[Pp]ro\s*[Tt]ip:.*?)$/s)
      if (protipMatch && protipMatch[2]) {
        const mainText = protipMatch[1].replace(/\s+$/, '')
        const tipText = protipMatch[2].replace(/^\s+/, '')
        if (mainText) {
          div.appendChild(document.createTextNode(mainText))
        }
        const tip = document.createElement('span')
        tip.className = 'fa-protip'
        tip.textContent = tipText
        div.appendChild(tip)
      } else {
        div.textContent = content
      }
    } else {
      // User message — plain text
      div.textContent = content
    }

    wrap.appendChild(div)
    wrap.scrollTop = wrap.scrollHeight
  }

  function renderQuickReplies(show) {
    const wrap = document.getElementById('fa-quick-replies')
    if (!wrap) return
    wrap.innerHTML = ''
    if (!show) return
    QUICK_REPLIES.forEach(function (text) {
      const b = document.createElement('button')
      b.textContent = text
      b.addEventListener('click', function () {
        // Special-case: cost-estimate quick reply opens the calculator modal
        if (/estimate.*cost/i.test(text) && typeof window.openFaisalCostCalculator === 'function') {
          renderQuickReplies(false)
          appendMessage('user', text)
          // Tell the user we're opening the calculator
          conversation.push({ role: 'user', content: text })
          const ack = "Opening our live cost calculator now — it pulls current 2026 market rates to give you an instant estimate.\n💡 Pro Tip: Pick the closest scope match first, then refine the features for the most accurate range."
          conversation.push({ role: 'assistant', content: ack })
          appendMessage('assistant', ack)
          saveHistory()
          setTimeout(function () {
            window.openFaisalCostCalculator()
          }, 400)
          return
        }
        const input = document.getElementById('fa-input')
        if (input) input.value = text
        handleSend()
      })
      wrap.appendChild(b)
    })
  }

  function showTyping() {
    const wrap = document.getElementById('fa-messages')
    if (!wrap) return
    let existing = document.getElementById('fa-typing')
    if (existing) return
    const div = document.createElement('div')
    div.className = 'fa-typing'
    div.id = 'fa-typing'
    div.innerHTML = '<span></span><span></span><span></span>'
    wrap.appendChild(div)
    wrap.scrollTop = wrap.scrollHeight
  }

  function hideTyping() {
    const t = document.getElementById('fa-typing')
    if (t) t.remove()
  }

  // ----- Conversation flow -----
  async function handleSend() {
    const input = document.getElementById('fa-input')
    if (!input) return
    const text = input.value.trim()
    if (!text || isTyping) return

    // Append user message
    conversation.push({ role: 'user', content: text })
    appendMessage('user', text)
    input.value = ''
    input.style.height = 'auto'
    renderQuickReplies(false)
    saveHistory()

    // Typing indicator
    isTyping = true
    const sendBtn = document.getElementById('fa-send')
    if (sendBtn) sendBtn.disabled = true
    showTyping()

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ history: conversation }),
      })
      const data = await res.json()
      hideTyping()
      if (data && data.success && data.reply) {
        conversation.push({ role: 'assistant', content: data.reply })
        appendMessage('assistant', data.reply)
      } else {
        const errMsg =
          (data && data.error) ||
          "I'm sorry — I couldn't reach my brain right now. Please try again."
        appendMessage('assistant', errMsg)
      }
    } catch (err) {
      hideTyping()
      appendMessage(
        'assistant',
        "I'm having trouble connecting. Please try again in a moment, or email hello@metamehar.com directly."
      )
    } finally {
      isTyping = false
      const sendBtn2 = document.getElementById('fa-send')
      if (sendBtn2) sendBtn2.disabled = false
      saveHistory()
    }
  }

  // ----- Open / close -----
  function openPanel() {
    const panel = document.getElementById('fa-panel-instance')
    const launcher = document.getElementById('fa-launcher-instance')
    if (!panel || !launcher) return
    panel.classList.add('is-open')
    launcher.classList.add('is-hidden')
    isOpen = true
    // First-open greeting
    if (conversation.length === 0) {
      conversation.push({ role: 'assistant', content: GREETING })
      appendMessage('assistant', GREETING)
      renderQuickReplies(true)
      saveHistory()
    }
    // Focus input after the open animation
    setTimeout(function () {
      const input = document.getElementById('fa-input')
      if (input) input.focus()
    }, 350)
  }

  function closePanel() {
    const panel = document.getElementById('fa-panel-instance')
    const launcher = document.getElementById('fa-launcher-instance')
    if (!panel || !launcher) return
    panel.classList.remove('is-open')
    launcher.classList.remove('is-hidden')
    isOpen = false
  }

  function togglePanel() {
    if (isOpen) closePanel()
    else openPanel()
  }

  // ----- Init on DOM ready -----
  function init() {
    const root = document.createElement('div')
    root.id = 'faisal-assistant-root'
    root.setAttribute('aria-live', 'polite')

    const launcher = buildLauncher()
    launcher.id = 'fa-launcher-instance'

    const panel = buildPanel()
    panel.id = 'fa-panel-instance'

    root.appendChild(launcher)
    root.appendChild(panel)
    document.body.appendChild(root)

    // Restore any saved history (without replaying greeting)
    conversation = loadHistory()
    if (conversation.length > 0) {
      conversation.forEach(function (m) {
        appendMessage(m.role === 'user' ? 'user' : 'assistant', m.content)
      })
    }

    // Auto-open after 6 seconds on first visit (only if no prior conversation)
    try {
      const seen = sessionStorage.getItem('faisal_assistant_seen')
      if (!seen && conversation.length === 0) {
        sessionStorage.setItem('faisal_assistant_seen', '1')
        setTimeout(function () {
          if (!isOpen) openPanel()
        }, 6000)
      }
    } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }
})()
