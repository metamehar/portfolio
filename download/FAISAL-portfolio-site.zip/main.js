document.addEventListener('DOMContentLoaded', () => {

  /* --- HEADER SCROLL ACTION --- */
  const header = document.querySelector('header');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });

  /* --- MOBILE BURGER DRAWER --- */
  const burger = document.querySelector('.burger-menu');
  const navLinks = document.querySelector('.nav-links');
  
  if (burger && navLinks) {
    burger.addEventListener('click', () => {
      burger.classList.toggle('active');
      navLinks.classList.toggle('active');
    });

    // Close mobile menu when clicking on links
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        burger.classList.remove('active');
        navLinks.classList.remove('active');
      });
    });
  }

  /* --- HERO SLIDER --- */
  const slides = document.querySelectorAll('.hero-slider .slide');
  const dotsContainer = document.querySelector('.slider-dots');
  const prevBtn = document.querySelector('.arrow-btn.prev');
  const nextBtn = document.querySelector('.arrow-btn.next');
  let currentSlide = 0;
  let slideInterval;

  if (slides.length > 0) {
    // Generate navigation dots
    slides.forEach((_, index) => {
      const dot = document.createElement('div');
      dot.classList.add('dot');
      if (index === 0) dot.classList.add('active');
      dot.addEventListener('click', () => goToSlide(index));
      if (dotsContainer) dotsContainer.appendChild(dot);
    });

    const dots = document.querySelectorAll('.slider-dots .dot');

    const updateSlider = () => {
      slides.forEach((slide, index) => {
        if (index === currentSlide) {
          slide.classList.add('active');
        } else {
          slide.classList.remove('active');
        }
      });

      if (dots.length > 0) {
        dots.forEach((dot, index) => {
          if (index === currentSlide) {
            dot.classList.add('active');
          } else {
            dot.classList.remove('active');
          }
        });
      }
    };

    const nextSlide = () => {
      currentSlide = (currentSlide + 1) % slides.length;
      updateSlider();
    };

    const prevSlide = () => {
      currentSlide = (currentSlide - 1 + slides.length) % slides.length;
      updateSlider();
    };

    const goToSlide = (index) => {
      currentSlide = index;
      updateSlider();
      resetInterval();
    };

    if (nextBtn) nextBtn.addEventListener('click', () => { nextSlide(); resetInterval(); });
    if (prevBtn) prevBtn.addEventListener('click', () => { prevSlide(); resetInterval(); });

    const startInterval = () => {
      slideInterval = setInterval(nextSlide, 6000);
    };

    const resetInterval = () => {
      clearInterval(slideInterval);
      startInterval();
    };

    startInterval();
  }

  /* --- TESTIMONIAL SLIDER --- */
  const testimonialSlides = document.querySelectorAll('.testimonial-slide');
  const tPrevBtn = document.querySelector('.testimonial-nav .prev');
  const tNextBtn = document.querySelector('.testimonial-nav .next');
  let currentTestimonial = 0;

  if (testimonialSlides.length > 0) {
    const updateTestimonials = () => {
      testimonialSlides.forEach((slide, index) => {
        if (index === currentTestimonial) {
          slide.classList.add('active');
        } else {
          slide.classList.remove('active');
        }
      });
    };

    const nextTestimonial = () => {
      currentTestimonial = (currentTestimonial + 1) % testimonialSlides.length;
      updateTestimonials();
    };

    const prevTestimonial = () => {
      currentTestimonial = (currentTestimonial - 1 + testimonialSlides.length) % testimonialSlides.length;
      updateTestimonials();
    };

    if (tNextBtn) tNextBtn.addEventListener('click', nextTestimonial);
    if (tPrevBtn) tPrevBtn.addEventListener('click', prevTestimonial);
  }

  /* --- STATS COUNT-UP ANIMATION --- */
  const stats = document.querySelectorAll('.stat-number');
  
  if (stats.length > 0) {
    const countUp = (element) => {
      const target = parseInt(element.getAttribute('data-target'), 10);
      const isPercent = element.getAttribute('data-format') === 'percent';
      const suffix = element.getAttribute('data-suffix') || '';
      const prefix = element.getAttribute('data-prefix') || '';
      let count = 0;
      const duration = 2000; // Animation duration in milliseconds
      const stepTime = Math.max(Math.floor(duration / target), 15);
      
      const timer = setInterval(() => {
        count += Math.ceil(target / (duration / stepTime));
        if (count >= target) {
          element.textContent = prefix + target + suffix;
          clearInterval(timer);
        } else {
          element.textContent = prefix + count + suffix;
        }
      }, stepTime);
    };

    const statsObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          countUp(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    stats.forEach(stat => statsObserver.observe(stat));
  }

  /* --- SCROLL REVEAL TRIGGERS --- */
  const reveals = document.querySelectorAll('.reveal');
  
  if (reveals.length > 0) {
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.15 });

    reveals.forEach(element => revealObserver.observe(element));
  }

  /* --- SCROLL TO TOP ACTION ---
     Removed: the floating arrow button was clashing with the AI assistant
     launcher (both sat at bottom-right). Scroll-to-top is now triggered by
     tapping the FAISAL logo in the header, which is the conventional pattern. */

  /* --- FORM SUBMISSIONS FEEDBACK --- */
  const newsletterForm = document.querySelector('.newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = newsletterForm.querySelector('input');
      const submitBtn = newsletterForm.querySelector('button');
      
      if (emailInput.value.trim() !== '') {
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = 'Subscribing...';
        
        setTimeout(() => {
          emailInput.value = '';
          submitBtn.innerHTML = 'Thank You!';
          submitBtn.style.background = '#2cffa5';
          
          setTimeout(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
            submitBtn.style.background = '';
          }, 3000);
        }, 1500);
      }
    });
  }

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = 'Sending Message...';
      
      setTimeout(() => {
        contactForm.reset();
        submitBtn.innerHTML = 'Message Sent!';
        submitBtn.style.background = '#2cffa5';
        
        // Show success popup alert
        const successMsg = document.createElement('div');
        successMsg.style.position = 'fixed';
        successMsg.style.bottom = '40px';
        successMsg.style.left = '40px';
        successMsg.style.background = '#191a24';
        successMsg.style.borderLeft = '4px solid #2cffa5';
        successMsg.style.color = '#fff';
        successMsg.style.padding = '16px 24px';
        successMsg.style.borderRadius = '8px';
        successMsg.style.boxShadow = '0 10px 30px rgba(0,0,0,0.5)';
        successMsg.style.zIndex = '1000';
        successMsg.innerHTML = '<strong>Success!</strong> Your message has been sent successfully.';
        document.body.appendChild(successMsg);
        
        setTimeout(() => {
          successMsg.style.opacity = '0';
          successMsg.style.transition = 'opacity 0.5s ease';
          setTimeout(() => successMsg.remove(), 500);
        }, 4000);

        setTimeout(() => {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalText;
          submitBtn.style.background = '';
        }, 3000);
      }, 1800);
    });
  }
});

/* ======================================================================
   FAISAL — Premium mouse-tracking glow for service cards
   Tracks the mouse position relative to each .service-card and exposes
   it as CSS custom properties (--mx, --my) so the radial gradient in
   the ::before pseudo-element follows the cursor.
   ====================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  const cards = document.querySelectorAll('.service-card, .value-card, .team-card');
  cards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      card.style.setProperty('--mx', x + '%');
      card.style.setProperty('--my', y + '%');
    });
  });
});

/* ======================================================================
   FAISAL — Make portfolio & blog cards fully clickable on mobile
   The whole card navigates, not just the tiny arrow icon.
   ====================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  // Portfolio cards: click anywhere on the card to navigate
  document.querySelectorAll('.portfolio-card').forEach(card => {
    card.style.cursor = 'pointer';
    card.addEventListener('click', function(e) {
      // Don't intercept clicks on the actual link elements (let them work naturally)
      if (e.target.closest('a')) return;
      const link = card.querySelector('.portfolio-title')?.getAttribute('href') ||
                   card.querySelector('.portfolio-btn')?.getAttribute('href') ||
                   'portfolio.html';
      window.location.href = link;
    });
  });

  // Blog cards: click anywhere on the card to navigate to blog.html
  document.querySelectorAll('.blog-card').forEach(card => {
    card.style.cursor = 'pointer';
    card.addEventListener('click', function(e) {
      if (e.target.closest('a')) return;
      const link = card.querySelector('.blog-title a')?.getAttribute('href') ||
                   card.querySelector('a')?.getAttribute('href') ||
                   'blog.html';
      window.location.href = link;
    });
  });

  // Service cards: clickable to open the AI assistant with a pre-filled question
  document.querySelectorAll('.service-card').forEach(card => {
    card.style.cursor = 'pointer';
    const serviceName = card.querySelector('h3')?.textContent?.trim() || '';
    card.addEventListener('click', function(e) {
      if (serviceName && typeof window.openFaisalCostCalculator === 'function') {
        // Open the AI assistant with a question about this service
        if (typeof window.openFaisalAssistant === 'function') {
          window.openFaisalAssistant('Tell me more about ' + serviceName);
        }
      }
    });
  });
});
